# INP2DAT
Convert Abaqus/CalculiX INP file (nodes and elements) to a Nastran/MYSTRAN DAT/BDF deck.
Primarily for use with M3D and solid element (4-node tet and 10-node tet).
