# INP2DAT
Convert Abaqus format INP to Nastran/MYSTRAN DAT/BDF format
